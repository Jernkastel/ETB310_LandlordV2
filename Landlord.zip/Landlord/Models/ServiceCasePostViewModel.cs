using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Landlord.Models
{
    public class ServiceCasePostViewModel
    {
        public int CaseNr { get; set; }

        public string CaseMessage { get; set; } 
    }
}